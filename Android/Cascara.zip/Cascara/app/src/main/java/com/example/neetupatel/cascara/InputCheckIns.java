package com.example.neetupatel.cascara;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class InputCheckIns extends Activity {

    private EditText coffeeShopName;
    private EditText order;
    private EditText coffeeScore;
    private EditText wifiScore;
    private Button addButton;
    private Button exportCheckIn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.checkin);

        coffeeShopName = findViewById(R.id.nameCI);
        order = findViewById(R.id.orderCI);
        coffeeScore = findViewById(R.id.coffeeScoreCI);
        wifiScore = findViewById(R.id.wifiScoreCI);
        addButton = findViewById(R.id.addCIButton);
        exportCheckIn = findViewById(R.id.exportCIButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double newCoffeeScore;
                double newWifiScore;

                newCoffeeScore = Double.parseDouble(coffeeScore.getText().toString());
                newWifiScore = Double.parseDouble(wifiScore.getText().toString());

                CheckIn newCheckIn = new CheckIn(coffeeShopName.getText().toString(), order.getText().toString(), newCoffeeScore, newWifiScore);
                CheckInManager.addCheckIn(newCheckIn);
            }
        });

        exportCheckIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ExportToCSVActivity.class);
                startActivity(i);
            }
        });
    }
}
