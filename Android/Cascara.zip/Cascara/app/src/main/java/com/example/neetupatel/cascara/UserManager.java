package com.example.neetupatel.cascara;

import java.util.ArrayList;

public class UserManager {

    static ArrayList<User> userList = new ArrayList<User>();

    public static void setUserList(ArrayList<User> userList) {
        UserManager.userList = userList;
    }

    public static ArrayList<User> getUserList()
    {
        return userList;
    }

    public static void addUser(User u)
    {
        userList.add(u);
    }

    public static boolean userEmpty()
    {
        return userList.isEmpty();
    }
}
