package com.example.neetupatel.cascara;

public class User {
    private String m_emailAddress;
    private String m_password;


    public User(String emailAddress, String password) {
        m_emailAddress = emailAddress;
        m_password = password;
    }

    public String getUserEmailAddress()
    {
        return m_emailAddress;
    }

    public void setUserEmailAddress(String emailAddress)
    {
        m_emailAddress = emailAddress;
    }

    public String getUserPassword()
    {
        return m_password;
    }

    public void setUserPassword(String password)
    {
        m_password = password;
    }
}
