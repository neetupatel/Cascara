package com.example.neetupatel.cascara;

import java.util.ArrayList;

public class CheckInManager {
    static ArrayList<CheckIn> checkInList = new ArrayList<CheckIn>();

    public static void setCheckInList(ArrayList<CheckIn> checkInList) {
        CheckInManager.checkInList = checkInList;
    }

    public static ArrayList<CheckIn> getCheckInList()
    {
        return checkInList;
    }

    public static void addCheckIn(CheckIn cI)
    {
        checkInList.add(cI);
    }
}
