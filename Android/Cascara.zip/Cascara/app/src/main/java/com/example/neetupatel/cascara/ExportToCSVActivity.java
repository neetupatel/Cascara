package com.example.neetupatel.cascara;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;


public class ExportToCSVActivity extends Activity {

    private Button exportButton;
    private String name;
    private String order;
    private double coffeeScore;
    private double wifiScore;
    private String checkInData;

    private final String checkInFile = "checkIn.csv";
    FileOutputStream myFile;
    File mFile;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exportusercheckin);

        exportButton = findViewById(R.id.exportButton);

        exportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportData();
            }
        });

    }

    private void exportData()
    {
        try {
            myFile = this.openFileOutput(checkInFile, MODE_PRIVATE);
            mFile = getFileStreamPath(checkInFile);

            ObjectOutputStream out = new ObjectOutputStream(myFile);

            for(int i = 0; i < CheckInManager.checkInList.size(); ++i) {
                name = CheckInManager.checkInList.get(i).getCoffeeName();
                order = CheckInManager.checkInList.get(i).getOrder();
                coffeeScore = CheckInManager.checkInList.get(i).getCoffeeScore();
                wifiScore = CheckInManager.checkInList.get(i).getWifiScore();

                checkInData = name + ", " + order + ", " + coffeeScore + ", " + wifiScore + "\n";
                out.writeObject(checkInData);
            }

            out.close();
        }

        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
