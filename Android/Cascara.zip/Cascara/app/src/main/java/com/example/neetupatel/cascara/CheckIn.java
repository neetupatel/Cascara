package com.example.neetupatel.cascara;

public class CheckIn {
    private String coffeeName;
    private String order;
    private double coffeeScore;
    private double wifiScore;

    public CheckIn(String name, String order, double coffeescore, double wifiscore) {
        this.coffeeName = name;
        this.order = order;
        this.coffeeScore = coffeescore;
        this.wifiScore = wifiscore;
    }

    public String getCoffeeName() {
        return coffeeName;
    }

    public void setCoffeeName(String coffeeName) {
        this.coffeeName = coffeeName;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public double getCoffeeScore() {
        return coffeeScore;
    }

    public void setCoffeeScore(double coffeeScore) {
        this.coffeeScore = coffeeScore;
    }

    public double getWifiScore() {
        return wifiScore;
    }

    public void setWifiScore(double wifiScore) {
        this.wifiScore = wifiScore;
    }
}
