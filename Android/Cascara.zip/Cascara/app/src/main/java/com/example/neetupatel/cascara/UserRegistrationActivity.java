package com.example.neetupatel.cascara;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserRegistrationActivity extends Activity {

    private EditText emailAddress;
    private EditText password;
    private EditText password2;
    private Button registerButton;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newuserregistration);


        emailAddress = findViewById(R.id.newEmailEditText);
        password = findViewById(R.id.newPassEditText);
        password2 = findViewById(R.id.newPass2EditText);
        registerButton = findViewById(R.id.newUserRegisterButton);


        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(isEmpty(emailAddress))
                {
                    emailAddress.setError("Enter your valid email.");
                }
                else if(isEmpty(password))
                {
                    password.setError("Enter your password.");
                }
                else if (password2.equals(password))
                {
                    User newUser = new User(emailAddress.getText().toString(), password.getText().toString());
                    UserManager.addUser(newUser);

                    Toast toast2 = Toast.makeText(UserRegistrationActivity.this,"Account created.", Toast.LENGTH_LONG);
                    toast2.show();

                    Intent i = new Intent(getApplicationContext(), LogInActivity.class);
                    startActivity(i);
                }
                else
                {
                    password.setError("Enter the same password for both fields.");
                    //Toast toast = Toast.makeText(UserRegistrationActivity.this,"Passwords do no match.", Toast.LENGTH_LONG);
                    //toast.show();
                }
            }
        });
    }

    private boolean isEmpty(EditText text)
    {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }

}
