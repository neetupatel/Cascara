package com.example.murphy.cascara;

import java.util.ArrayList;

public class CoffeeShop {
    private int houseID;
    private String houseName;
    private double coffeeScore;
    private double wifiScore;
    private ArrayList<String> atmosphere;
    private ArrayList<String> amenities;
    private String bestOrder;

    public CoffeeShop() {
        houseID = 0;
        houseName = "";
        coffeeScore = 0;
        wifiScore = 0;
        atmosphere = new ArrayList<>();
        amenities = new ArrayList<>();
        bestOrder = "";
    }


    public CoffeeShop(int houseID, String houseName, double coffeeScore, double wifiScore, ArrayList<String> atmosphere) {
        this.houseID = houseID;
        this.houseName = houseName;
        this.coffeeScore = coffeeScore;
        this.wifiScore = wifiScore;
        this.atmosphere = atmosphere;
    }

    public int getHouseID() {
        return houseID;
    }

    public void setHouseID(int houseID) {
        this.houseID = houseID;
    }

    public String getHouseName() {
        return houseName;
    }

    public void setHouseName(String houseName) {
        this.houseName = houseName;
    }

    public double getCoffeeScore() {
        return coffeeScore;
    }

    public void setCoffeeScore(double coffeeScore) {
        this.coffeeScore = coffeeScore;
    }

    public double getWifiScore() {
        return wifiScore;
    }

    public void setWifiScore(double wifiScore) {
        this.wifiScore = wifiScore;
    }

    public ArrayList<String> getAtmosphere() {
        return atmosphere;
    }

    public void setAtmosphere(ArrayList<String> atmosphere) {
        this.atmosphere = atmosphere;
    }
}
