package com.example.murphy.cascara;

public class API {
    private static final String ROOT_URL = "http://192.168.56.1/CascaraAPI/v1/"; //set to IP
    public static final String URL_GET_COFFEESHOPS = ROOT_URL + "getcoffeeshops.php";
    public static final String URL_CHECK_IN = ROOT_URL + "checkin.php";
    public static final String URL_LOG_IN = ROOT_URL + "login.php";
    public static final String URL_DELETE_USER = ROOT_URL + "deleteuser.php";

}
