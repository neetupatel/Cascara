package com.example.murphy.cascara;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/** @Author Murphy Studebaker
 *
 * This class handles all of the data communication
 * between the networking classes and the ViewModels.
 */
public class CascaraRepository {
    private CoffeeShop[] coffeeShops;
    private CoffeeShop activeCoffeeShop;
    private User activeUser;
    API api;
    Context appContext;
    //RequestQueue que;

    public CascaraRepository(Context context) {
        activeCoffeeShop = null;
        appContext = context;
        //que = Volley.newRequestQueue(context);
    }

    public CoffeeShop[] getCoffeeShops() {
        return coffeeShops;
    }

    public void setCoffeeShops(CoffeeShop[] coffeeShops) {
        this.coffeeShops = coffeeShops;
    }

    public CoffeeShop getActiveCoffeeShop() {
        return activeCoffeeShop;
    }

    public void setActiveCoffeeShop(CoffeeShop activeCoffeeShop) {
        this.activeCoffeeShop = activeCoffeeShop;
    }


    public User getActiveUser() {
        return activeUser;
    }

    public void setActiveUser(User activeUser) {
        this.activeUser = activeUser;
    }

    /**
    public void fetchCoffeeShops() {
        //perform network reqeust to get coffee shop
    }

    public void getUserCheckIns() {

    }
    */

    /**
    public void deleteUser() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, api.URL_LOG_IN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            // if message['error'] == false, user was deleted, display log in screen
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        //adding our stringrequest to queue
        Volley.newRequestQueue(appContext).add(stringRequest);
    }*/


    public void logInUser(String username, String password) {
        //perform network request to validate user info
        //load user class for active user
        StringRequest stringRequest = new StringRequest(Request.Method.POST, api.URL_LOG_IN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //converting response to json object
                            JSONObject obj = new JSONObject(response);

                            //if no error in response
                            if (!obj.getBoolean("error")) {
                                Toast.makeText(appContext, obj.getString("message"), Toast.LENGTH_SHORT).show();

                                //getting the user from the response
                                JSONObject userJson = obj.getJSONObject("user");

                                //creating a new user object
                                User user = new User(
                                        userJson.getInt("userID"),
                                        userJson.getString("fist_name"),
                                        userJson.getString("last_name"),
                                        userJson.getString("email"),
                                        userJson.getInt("total_checkins")
                                );

                                activeUser = user;
                                Toast.makeText(appContext, "Logged in " + user.getFirstName(), Toast.LENGTH_LONG).show();

                                //storing the user in shared preferences
                                //SharedPrefManager.getInstance(getApplicationContext()).userLogin(user);
                            } else {
                                Toast.makeText(appContext, obj.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);
                return params;
            }
        };

        //adding our stringrequest to queue
        Volley.newRequestQueue(appContext).add(stringRequest);
    }
}
