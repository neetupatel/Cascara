package com.example.murphy.cascara;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class CoffeeProfileActivity extends AppCompatActivity {
    //Views
    TextView name, wifiScore, coffeeScore;
    ImageView photo, wifiIcon, coffeeIcon;
    Button checkin;
    ChipGroup atmospheres;

    //Data Source
    CascaraApplication app;
    CoffeeShop activeShop;


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_coffee_profile);
        app = (CascaraApplication) getApplication();
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.coffeeTool);
        setSupportActionBar(toolbar);
        ActionBar actionbar = getSupportActionBar();
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);

        activeShop = app.getRepo().getActiveCoffeeShop();
        bindCoffeeInfoToUI(activeShop);

        checkin = findViewById(R.id.checkIn);
        coffeeIcon = findViewById(R.id.coffeeScoreImg);
        wifiIcon = findViewById(R.id.wifiScoreImg);
        coffeeIcon.setImageResource(R.drawable.ic_free_breakfast);
        wifiIcon.setImageResource(R.drawable.ic_wifi_black_24dp);

        checkin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextScreen = new Intent(getApplicationContext(), CheckInActivity.class);
                startActivity(nextScreen);
            }
        });
    }

    public void bindCoffeeInfoToUI(CoffeeShop activeShop) {
        name = findViewById(R.id.coffeeName);
        wifiScore = findViewById(R.id.wifiScore);
        coffeeScore = findViewById(R.id.coffeeScore);
        photo = findViewById(R.id.coffeeImg);
        atmospheres = findViewById(R.id.atmosphereGroup);

        // things we already know from database
        name.setText(activeShop.getHouseName());
        wifiScore.setText(Double.toString(activeShop.getWifiScore()));
        coffeeScore.setText(Double.toString(activeShop.getCoffeeScore()));
        photo.setImageResource(R.drawable.default_coffee_house);

        // load atmosphere chips
        ArrayList<String> atmosphereTexts = activeShop.getAtmosphere();
        for (int i = 0; i < atmosphereTexts.size(); ++i) {
            Chip newChip = new Chip(this);
            newChip.setText(atmosphereTexts.get(i));
            atmospheres.addView(newChip);
        }
    }

}
