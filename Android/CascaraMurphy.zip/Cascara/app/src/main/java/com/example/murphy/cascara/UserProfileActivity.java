package com.example.murphy.cascara;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class UserProfileActivity extends AppCompatActivity {
    //Views
    TextView name, checkins;
    ImageView profilepic;

    //Data
    CascaraApplication app;
    //CascaraRepository repo;

    //Specifices actions for menu items
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case android.R.id.home:
                //mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
            case R.id.delete_account:
                //app.getRepo().deleteUser();
                //bring up the settings UI and refresh list
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_user_profile);
        //repo = new CascaraRepository(this);

        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.userTool);
        setSupportActionBar(toolbar);
        ActionBar actionbar = getSupportActionBar();
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);


        app = (CascaraApplication) getApplication();
        name = findViewById(R.id.user_name);
        checkins = findViewById(R.id.user_checkins);
        profilepic = findViewById(R.id.user_img);
        profilepic.setImageResource(R.drawable.latte);


        User active = new User(1,"harry","potter","hpotter12@gmail.com",5);

        /** THIS DOESNT WORK YET
        app.getRepo().logInUser("myemail","mypassword");
        if(app.getRepo().getActiveUser() != null) {
            active = app.getRepo().getActiveUser();
        }
         */

        name.setText(active.getFirstName() + " " + active.getLastName());
        checkins.setText(Integer.toString(active.getTotalCheckins()) + " TOTAL CHECKINS");
    }
}
