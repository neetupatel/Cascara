package com.example.murphy.cascara;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CheckInActivity extends AppCompatActivity {
    //Views
    Button contribute;
    Spinner menuSpinner;
    TextView title;

    //Data
    CascaraApplication app;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_checkin);
        app = (CascaraApplication) getApplication();

        // instantiate views
        contribute = findViewById(R.id.btn_contribute);
        title = findViewById(R.id.title);

//        title.setText("Checking in at " + app.getRepo().getActiveCoffeeShop().getHouseName());

        // create spinner
        String[] spinnerArray = {"Cappuccino","Drip Coffee","Latte","Cold Brew"};
        menuSpinner = findViewById(R.id.menuSpinner);
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item,
                        spinnerArray);
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout
                .simple_spinner_dropdown_item);
        menuSpinner.setAdapter(spinnerArrayAdapter);

        contribute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // send data to checkin database in another thread
                //captureInput();
                Toast.makeText(getApplicationContext(),"Thanks for contributing!",Toast.LENGTH_LONG).show();
                finish();
            }
        });
    }
/**
    public void captureInput() {
        //do something

        CheckIn chk = new CheckIn();
        //store it locally for now
        app.getRepo().getActiveUser().addCheckIn(chk);
        //then send it to the database
    }
 */
}
